/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reminder.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mahesh
 */
public class ValidateUser {

    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public ValidateUser(String username) {
        this.username = username;
    }

    public boolean validate(String username) {
        try {
            String connectionString = "jdbc:mysql://localhost:3306/sample";
            String user = "root";
            String pwd = "1234";

            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(connectionString, user, pwd);
            PreparedStatement getUser = conn.prepareStatement("select * from user where username = ?");
            getUser.setString(1, username);
            ResultSet rs = getUser.executeQuery();
            if(rs.next())
                return true;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            Logger.getLogger(ValidateUser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(ValidateUser.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }
}
